# Crypto G

Android ARMv7 cryptocurrency wallet interface.

## Project

- android/main.py — Kivy application
- android/buildozer.spec — Android APK configuration
- server/api.py — Windows API
- server/requirements.txt — server dependencies

## Windows server

Install Python dependencies:

    pip install -r requirements.txt

Set a long random API_SECRET environment variable.

Start:

    uvicorn api:app --host 0.0.0.0 --port 8000

Find your PC IP using:

    ipconfig

Set the IP in android/main.py:

    API = "http://YOUR_PC_IP:8000"

Set the same secret in API_KEY and API_SECRET.

## Android APK

Build using Linux or WSL with Buildozer:

    pip install buildozer
    buildozer android debug

APK output is created in bin/.

## Important

This is a starter interface and demo balance API.
It does not automatically process blockchain deposits or payouts.
Do not use it for real funds without proper authentication,
transaction verification and a security audit.

suuuuhs
