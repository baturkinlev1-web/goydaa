# Crypto G — инструкция

1. Распакуй проект.
2. Установи Python на Windows.
3. Установи зависимости сервера.
4. Настрой API_SECRET.
5. Узнай IP компьютера через ipconfig.
6. Укажи IP компьютера в android/main.py.
7. Для APK используй Linux/WSL и Buildozer.

Приложение рассчитано на ARMv7.
suuuuhs
