[app]
title = Crypto G
package.name = cryptog
package.domain = org.cryptog
source.dir = .
source.include_exts = py
version = 1.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.arch = armeabi-v7a
android.api = 35
android.minapi = 24

[buildozer]
log_level = 2
warn_on_root = 1
