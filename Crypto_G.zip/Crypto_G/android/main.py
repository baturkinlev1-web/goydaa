import json
import threading
import urllib.request

from kivy.app import App
from kivy.lang import Builder
from kivy.clock import Clock
from kivy.uix.popup import Popup
from kivy.uix.label import Label

API = "http://192.168.1.100:8000"
API_KEY = "CHANGE_ME_SECRET"
USER_ID = 123456789

KV = """
BoxLayout:
    orientation: "vertical"
    padding: 20
    spacing: 12

    canvas.before:
        Color:
            rgba: .025, .04, .10, 1
        Rectangle:
            pos: self.pos
            size: self.size

    Label:
        text: "CRYPTO G"
        font_size: "30sp"
        bold: True
        color: .2, .6, 1, 1
        size_hint_y: .15

    BoxLayout:
        orientation: "vertical"
        padding: 15
        canvas.before:
            Color:
                rgba: .08, .14, .27, 1
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [20]

        Label:
            text: "ОБЩИЙ БАЛАНС"
            color: .7, .8, 1, 1

        Label:
            id: total
            text: "Загрузка..."
            font_size: "32sp"
            bold: True

        Label:
            id: currencies
            text: "TON: -- | USDT: --"

    Button:
        text: "↻ Обновить баланс"
        on_release: app.refresh_balance()

    Button:
        text: "📥 Пополнить"
        on_release: app.popup("Пополнение", "Создание заявки через сервер.")

    Button:
        text: "📤 Вывести"
        on_release: app.popup("Вывод", "Заявка на вывод средств.")

    Button:
        text: "🔄 Перевод"
        on_release: app.popup("Перевод", "Внутренний перевод Crypto G.")

    Button:
        text: "📜 История"
        on_release: app.popup("История", "История операций.")

    Button:
        text: "⚙ Настройки"
        on_release: app.popup("Настройки", "Crypto G ARMv7")
"""

class CryptoG(App):
    def build(self):
        self.title = "Crypto G"
        self.ui = Builder.load_string(KV)
        Clock.schedule_once(lambda dt: self.refresh_balance(), 1)
        return self.ui

    def request(self, path):
        req = urllib.request.Request(
            API + path,
            headers={"X-API-Key": API_KEY}
        )
        with urllib.request.urlopen(req, timeout=10) as response:
            return json.loads(response.read())

    def refresh_balance(self):
        def worker():
            try:
                data = self.request("/balance/" + str(USER_ID))
                ton = float(data["ton"])
                usdt = float(data["usdt"])
                Clock.schedule_once(
                    lambda dt: self.update_balance(ton, usdt)
                )
            except Exception as error:
                Clock.schedule_once(
                    lambda dt: self.error(str(error))
                )

        threading.Thread(target=worker, daemon=True).start()

    def update_balance(self, ton, usdt):
        self.ui.ids.total.text = f"{usdt:.2f} USDT"
        self.ui.ids.currencies.text = (
            f"TON: {ton:.4f} | USDT: {usdt:.2f}"
        )

    def error(self, error):
        self.ui.ids.total.text = "Нет соединения"
        print(error)

    def popup(self, title, message):
        Popup(
            title=title,
            content=Label(text=message),
            size_hint=(.85, .4)
        ).open()

if __name__ == "__main__":
    CryptoG().run()
