from fastapi import FastAPI, Header, HTTPException
import sqlite3
import os

app = FastAPI(title="Crypto G API")

SECRET = os.getenv("API_SECRET", "CHANGE_ME_SECRET")
DB = "crypto_g.sqlite3"

def connect():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

with connect() as con:
    con.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            ton REAL DEFAULT 0,
            usdt REAL DEFAULT 0
        )
    """)
    con.execute(
        "INSERT OR IGNORE INTO users(id) VALUES(123456789)"
    )

def auth(key):
    if not SECRET or SECRET == "CHANGE_ME_SECRET" or key != SECRET:
        raise HTTPException(401, "Unauthorized")

@app.get("/")
def home():
    return {"name": "Crypto G", "status": "online"}

@app.get("/balance/{user_id}")
def balance(user_id: int, x_api_key: str = Header(default="")):
    auth(x_api_key)
    with connect() as con:
        user = con.execute(
            "SELECT * FROM users WHERE id=?", (user_id,)
        ).fetchone()
    if not user:
        raise HTTPException(404, "User not found")
    return {"ton": user["ton"], "usdt": user["usdt"]}
